import {BookInfo} from "../../app/bookInfo";
export const MYBOOKS: BookInfo[] = 
[{bname: "Flowers in the Attic",
  bauthor: "Virginia Andrews",
  bgenre: "Drama",
  byearpb: 1980,
  bpicture:'assets/images/FlowersInTheAttic.jpg'
  },
  {bname: "Jewels",
  bauthor: "Danielle Steel",
  bgenre: "Historical Romance",
  byearpb: 1992,
  bpicture:'assets/images/Jewels.jpg'
  },
  {bname: "Carolina Moon",
  bauthor: "Nora Roberts",
  bgenre: "Romance",
  byearpb: 2000,
  bpicture:'assets/images/CarolinaMoon.jpg'
  }
]